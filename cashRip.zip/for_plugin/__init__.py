from electroncash.i18n import _

fullname = 'Cash Rip'
description = _('Allows Cash Rip 2of2 multisig payments.  Requires Electron Cash version >= 3.3.1')
available_for = ['qt']
